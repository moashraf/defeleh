<?php
namespace App\Http\Controllers\api;
use  DB ;
use App\Facades\Helpers;
use App\Http\Controllers\Controller;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use App\Models\userFollow;

class timelineController extends Controller
{
  
    

    public function timeline (Request $request){

        $validator = Validator::make($request->all(), [
            'user_id' => 'required',
         ]);

        if ($validator->fails())
            return Helpers::returnJsonResponse(false,'Error , Missing inputs  user id ...',null);
  
  $userFollow=userFollow::where('user_id', $request->user_id )->pluck('followed_user_id');
  $post = DB::table('post') ->whereIn('ownerid', $userFollow)->get();
               
         if( !$post->isEmpty()){      
     return Helpers::returnJsonResponse(true,'    successfully...', $post);
         } else{
            return Helpers::returnJsonResponse(false,'error   ...',null);}
  
                    
  
 

    }// end apiSignup function






    public function apiSignup(Request $request){
 
          $validator = Validator::make($request->all(), [
            'name' => 'required|min:3',
            'email' => 'required|email|unique:users',
            'password' => 'required'
        ]);

        if ($validator->fails())
            return Helpers::returnJsonResponse(false,'Error , Missing inputs or email already exists...',null);


        $inputs = $request->all();
        $inputs['password'] = bcrypt($request->password);
        $inputs['user_role'] = 0;
        $inputs['api_token'] = str_random(25);
        $activate=   (rand(1000,3000));
        $inputs['activate'] =   $activate;

        if ($user = User::create($inputs)){


            $to = "$request->email";
            $subject = "defileh email";

            $message =   apiSigninController::mail_code($activate,$request->email);;

            // Always set content-type when sending HTML email
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

            // More headers
            $headers .= 'From: <info@defileh.com>' . "\r\n";

            mail($to, $subject, $message, $headers);
            
            
            
            
            
            $profileInputs = [];
            
            $profileInputs['fullname'] = $request->input('fullname');
            $profileInputs['cellphone'] = $request->input('cellphone');
            $profileInputs['profileimage'] = "null";
            $profileInputs['address'] = "null";

            if (! $user->profile()->create($profileInputs))
                return Helpers::returnJsonResponse(false,'error creating Profile...',null);

            return Helpers::returnJsonResponse(true,'user created successfully...', $user);
            // add profile
        } else{
            return Helpers::returnJsonResponse(false,'error creating user...',null);
        }// end else

    } // end apiSignup function

}
