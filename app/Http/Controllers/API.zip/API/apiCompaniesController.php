<?php
namespace App\Http\Controllers\api;

use App\Models\company;
use App\Models\companycategory;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use App\Facades\Helpers;
use App\Http\Requests\UpdatecompanyRequest;
use App\Repositories\companyRepository;
use App\Http\Controllers\AppBaseController;
use Illuminate\Http\Request;
use Flash;
use Prettus\Repository\Criteria\RequestCriteria;
use Response;

class apiCompaniesController extends AppBaseController
{
    /** @var  companyRepository */
    private $companyRepository;

    public function __construct(companyRepository $companyRepo)
    {
        $this->companyRepository = $companyRepo;
    }

    public static function fileToUpload($image)
    {

        $nameDataSheet = "picture" . rand();
        $imageNameDataSheet = $nameDataSheet . '.' . $image->getClientOriginalExtension();
        $image->move(base_path() . '/public/upload/', $imageNameDataSheet);
        return $imageNameDataSheet;
    }

    public function cat($cat)
    {
        $companies = company::where('categoryid', '=', $cat)->get();

        if (!$companies->isEmpty()) return Helpers::returnJsonResponse(true, 'companies listed successfully ..', $companies);
        else return Helpers::returnJsonResponse(false, 'companies not existed ..', null);

    }

    public function cat_and_company()
    {

        $cat_and_company = companycategory::with('get_company')->get();

        if (!$cat_and_company->isEmpty()) return Helpers::returnJsonResponse(true, 'cat and company listed successfully ..', $cat_and_company);
        else return Helpers::returnJsonResponse(false, 'cat and company  not existed ..', null);

    }

    public function store(Request $request)
    {
        $rules = ['name' => 'required', 'categoryid' => 'required', 'ownerid' => 'required', 'image' => 'required|max:10000', // max 10000kb
        'address' => 'required', 'phones' => 'required', 'description' => 'required'];

        $validation = Helpers::validate($request->all() , $rules);

        if ($validation != false) return Helpers::returnJsonResponse(false, $validation, null);

        $inputs = $request->all();
        if (!empty($request->file('image')))
        {
            $imageName = Helpers::uploadImage64($request->file('image'));

            //$imageName = Helpers::uploadImage($request->file('image'));
            $inputs['image'] = $imageName;
        }

        if ($company = company::create($inputs)) return Helpers::returnJsonResponse(true, 'company created successfully ..', $company);
        else return Helpers::returnJsonResponse(false, 'error creating company ..', null);

    }

    /**
     * Display the specified company.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function show($id)
    {

        $companies = company::where('id', '=', $id)->with('get_company_cat')
            ->with('get_company_products')
            ->with('get_company_post')
            ->with('get_company_user')
            ->with('get_company_jobs')
            ->first();

        if (!is_null($companies)) return Helpers::returnJsonResponse(true, 'companies listed successfully ..', $companies);
        else return Helpers::returnJsonResponse(false, 'no companies existed ..', null);

    }

    public function company_like()
    {

        $companies = company::with('get_like')->get();
        dd($companies->get_like());
        $a = array(
            "red",
            "green"
        );
        foreach ($companies as $companies_val)
        {

            array_push($a, $companies->get_like());

            // print_r($companies_val->get_like())  ;
            
        }
        if (!is_null($companies)) return Helpers::returnJsonResponse(true, 'companies listed successfully ..', $a);
        else return Helpers::returnJsonResponse(false, 'no companies existed ..', null);

    }

    public function get_popular()
    {

        $companies = company::where('popular', '=', 1)->get();

        if (!is_null($companies)) return Helpers::returnJsonResponse(true, 'companies listed successfully ..', $companies);
        else return Helpers::returnJsonResponse(false, 'no companies existed ..', null);

    }

    /**
     * Show the form for editing the specified company.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function edit($id)
    {

    }

    /**
     * Update the specified company in storage.
     *
     * @param  int              $id
     * @param UpdatecompanyRequest $request
     *
     * @return Response
     */
    public function update($id, UpdatecompanyRequest $request)
    {

    }

    /**
     * Remove the specified company from storage.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function destroy($id)
    {

    }
}

